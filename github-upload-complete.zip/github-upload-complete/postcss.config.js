export default {
  plugins: {
    autoprefixer: {}
  }
}

